import os
import random
import time

import pytest

import engine_adapter as ea
from heuristic import legal_moves, win_threats
from run_experiments import load_bot
from santorini_engine import BoardState, apply_action, legal_actions_from, public_state_for, setup
from santorini_harness import MatchConfig, TerminationReason, run_santorini_tournament
from santorini_types import Coordinate
from search_bot import SearchBot

SRC = os.path.join(os.path.dirname(__file__), "..", "src")
RANDOM_BOT = os.environ.get("RANDOM_BOT_PATH", os.path.join(SRC, "random_bot.py"))
FORFEITS = {TerminationReason.BOT_EXCEPTION, TerminationReason.TIME_LIMIT, TerminationReason.INVALID_ACTION}


# --- Helpers ------------------------------------------------------------------------
def random_position(seed, plies):
    """Play `plies` random legal actions from the seeded opening."""
    rng = random.Random(seed)
    board = setup(seed)
    for _ in range(plies):
        actions = legal_actions_from(board)
        if not actions or board.winner is not None:
            break
        board = apply_action(board, rng.choice(actions))
    return board


def flat_heights():
    return [[0] * 5 for _ in range(5)]


def make_board(heights, mine, theirs):
    return BoardState(
        heights=tuple(tuple(r) for r in heights),
        workers=(tuple(Coordinate(*c) for c in mine), tuple(Coordinate(*c) for c in theirs)),
        current_player=0, turn_number=10, winner=None,
    )


# --- Adapter correctness ----------------------------------------------------------
def test_board_from_public_puts_us_first_and_keeps_the_board():
    for player in (0, 1):
        board = random_position(seed=3, plies=7)
        public = public_state_for(board, player)
        rebuilt = ea.board_from_public(public)
        assert rebuilt.current_player == ea.ME
        assert rebuilt.heights == board.heights
        assert rebuilt.workers[ea.ME] == board.workers[player]
        assert rebuilt.workers[ea.OPPONENT] == board.workers[1 - player]


def test_heuristic_move_rules_match_the_engine():
    """Our heuristic re-implements movement; it must agree with the official rules."""
    for seed in range(30):
        board = random_position(seed, plies=seed % 20)
        if board.winner is not None:
            continue
        view = ea.to_view(board, board.current_player)
        occupied = set(view.my_workers) | set(view.opp_workers)
        engine_moves = {(a.worker, (a.move_to.row, a.move_to.column)) for a in legal_actions_from(board)}
        our_moves = {(i, m) for i, w in enumerate(view.my_workers) for m in legal_moves(view, w, occupied)}
        assert our_moves == engine_moves


# --- Bot behaviour in real positions -------------------------------------------------
def test_bot_takes_an_immediate_win():
    h = flat_heights()
    h[2][2], h[2][3] = 2, 3
    board = make_board(h, mine=[(2, 2), (0, 0)], theirs=[(4, 4), (4, 0)])
    bot = SearchBot(max_depth=2, strict=True, time_fraction=None)
    action = bot.choose_action(public_state_for(board, 0), legal_actions_from(board), 2.0)
    assert (action.move_to.row, action.move_to.column) == (2, 3)


def test_bot_blocks_an_opponent_win_threat():
    h = flat_heights()
    h[2][2], h[2][3] = 2, 3                       # opponent on level 2 next to level 3
    board = make_board(h, mine=[(3, 4), (4, 0)], theirs=[(2, 2), (0, 0)])
    bot = SearchBot(max_depth=2, strict=True, time_fraction=None)
    action = bot.choose_action(public_state_for(board, 0), legal_actions_from(board), 2.0)
    after = apply_action(board, action)
    opp = ea.to_view(after, 1)
    occupied = set(opp.my_workers) | set(opp.opp_workers)
    assert not any(win_threats(opp, w, occupied) for w in opp.my_workers)


@pytest.mark.slow
def test_module_choose_action_is_legal_and_within_time():
    import search_bot
    for seed in range(5):
        board = random_position(seed, plies=6)
        legal = legal_actions_from(board)
        if not legal or board.winner is not None:
            continue
        start = time.perf_counter()
        action = search_bot.choose_action(public_state_for(board, board.current_player), legal, 2.0)
        assert time.perf_counter() - start < 2.0
        assert action in legal


# --- Full games through the official harness ---------------------------------------
@pytest.mark.slow
def test_full_harness_game_has_no_forfeit():
    search = SearchBot(max_depth=2, strict=True)
    result = run_santorini_tournament(search.choose_action, load_bot(RANDOM_BOT),
                                      config=MatchConfig(seed=1), num_games=1)[0]
    assert result.reason not in FORFEITS, result.detail


@pytest.mark.slow
def test_search_bot_beats_random_bot_most_of_the_time():
    random_bot = load_bot(RANDOM_BOT)
    wins = 0
    for seed in range(6):
        random.seed(seed)
        search = SearchBot(max_depth=1, seed=seed, strict=True)
        search_first = seed % 2 == 0
        bots = (search.choose_action, random_bot) if search_first else (random_bot, search.choose_action)
        result = run_santorini_tournament(*bots, config=MatchConfig(seed=seed), num_games=1)[0]
        wins += result.winner == (0 if search_first else 1)
    assert wins >= 5