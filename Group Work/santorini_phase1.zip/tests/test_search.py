import math
import random

from heuristic import WIN_SCORE
from search_bot import SearchBot


# --- Fake game 1: hand-written tree --------------------------------------------
class DictGame:
    """nodes[name] = {"player": 0/1, "children": {action: name},
                      "winner": 0/1 (terminal only), "value": float (player 0's view)}"""
    def __init__(self, nodes):
        self.nodes = nodes

    def current_player(self, s):
        return self.nodes[s]["player"]

    def successors(self, s):
        return list(self.nodes[s].get("children", {}).items())

    def terminal_score(self, s, player):
        if "winner" not in self.nodes[s]:
            return None
        return 1 if self.nodes[s]["winner"] == player else -1

    def evaluate(self, s, player):
        v = self.nodes[s].get("value", 0.0)
        return v if player == 0 else -v


# --- Fake game 2: uniform random tree, for comparison with plain minimax -------
class TreeGame:
    def __init__(self, branching, depth, seed):
        self.b, self.d, self.seed = branching, depth, seed

    def current_player(self, s):
        return len(s) % 2

    def successors(self, s):
        return [] if len(s) >= self.d else [(i, s + (i,)) for i in range(self.b)]

    def terminal_score(self, s, player):
        return None

    def evaluate(self, s, player):
        v = random.Random(f"{self.seed}-{s}").uniform(-100, 100)
        return v if player == 0 else -v


def plain_minimax(game, s, depth, me):
    if depth == 0:
        return game.evaluate(s, me)
    vals = [plain_minimax(game, c, depth - 1, me) for _, c in game.successors(s)]
    return max(vals) if game.current_player(s) == me else min(vals)


def count_minimax_nodes(game, s, depth):
    if depth == 0:
        return 1
    return 1 + sum(count_minimax_nodes(game, c, depth - 1) for _, c in game.successors(s))


# --- Tests -----------------------------------------------------------------------
def test_takes_immediate_win():
    g = DictGame({
        "root": {"player": 0, "children": {"meh": "A", "win": "W"}},
        "A": {"player": 1, "value": 999},
        "W": {"player": 1, "winner": 0},
    })
    assert SearchBot(game=g, max_depth=2).search("root") == "win"


def test_lookahead_avoids_trap_that_depth_one_falls_for():
    g = DictGame({
        "root": {"player": 0, "children": {"greedy": "G", "safe": "S"}},
        "G":    {"player": 1, "value": 50, "children": {"punish": "GW", "meh": "G2"}},
        "GW":   {"player": 0, "winner": 1},
        "G2":   {"player": 0, "value": 50},
        "S":    {"player": 1, "value": 0, "children": {"x": "S1"}},
        "S1":   {"player": 0, "value": 0},
    })
    assert SearchBot(game=g, max_depth=1).search("root") == "greedy"
    assert SearchBot(game=g, max_depth=2).search("root") == "safe"


def test_alphabeta_matches_minimax_and_prunes():
    for seed in range(10):
        for depth in (2, 3, 4):
            g = TreeGame(branching=4, depth=depth, seed=seed)
            bot = SearchBot(game=g, max_depth=depth, seed=seed)
            bot.search(())
            assert math.isclose(bot.last_stats["value"], plain_minimax(g, (), depth, me=0))
            assert bot.last_stats["nodes"] <= count_minimax_nodes(g, (), depth)


def test_ordering_does_not_change_the_answer():
    g = TreeGame(branching=5, depth=3, seed=7)
    a, b = SearchBot(game=g, max_depth=3, use_ordering=True), SearchBot(game=g, max_depth=3, use_ordering=False)
    a.search(())
    b.search(())
    assert math.isclose(a.last_stats["value"], b.last_stats["value"])


def test_time_limited_search_returns_an_action_in_time():
    g = TreeGame(branching=6, depth=6, seed=1)
    bot = SearchBot(game=g, max_depth=6)
    action = bot.search((), time_limit=0.05)
    assert action in range(6)
    assert bot.last_stats["ms"] < 200


def test_same_seed_gives_same_choice():
    g = TreeGame(branching=4, depth=2, seed=3)
    assert SearchBot(game=g, max_depth=2, seed=42).search(()) == SearchBot(game=g, max_depth=2, seed=42).search(())


def test_faster_wins_score_higher():
    assert WIN_SCORE - 1 > WIN_SCORE - 3