"""
search_bot.py - Alpha-beta look-ahead bot for the Santorini course harness.

Harness contract: module-level choose_action(state, legal_actions, time_limit_seconds)
returning one member of legal_actions before the deadline (overrunning forfeits).
Depth is in plies: 1 ply = one complete action (move + build) by one player.
"""
import math
import os
import random
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import engine_adapter as ea          # noqa: E402
from heuristic import WIN_SCORE      # noqa: E402


class SearchTimeout(Exception):
    """Raised inside the search when the time budget for this move is used up."""


class SearchBot:
    # -----------------------------------------------------------------------
    # SECTION 1: Configuration
    # -----------------------------------------------------------------------
    def __init__(self, game=None, max_depth: int = 3, seed: int = 0,
                 use_ordering: bool = True, time_fraction: float | None = 0.75,
                 strict: bool = False):
        self.game = game if game is not None else ea.SantoriniGame()
        self.max_depth = max_depth          # deepest iteration to attempt
        self.time_fraction = time_fraction  # share of the harness limit to use; None = fixed depth
        self.use_ordering = use_ordering
        self.strict = strict                # True in tests: raise instead of falling back
        self.rng = random.Random(seed)      # reproducible tie-breaking
        self.last_stats: dict = {}
        self.me = None
        self.nodes = 0
        self._deadline = None

    def reset(self, seed: int):
        self.rng = random.Random(seed)

    # -----------------------------------------------------------------------
    # SECTION 2: Harness-facing entry point (with a safety net)
    # -----------------------------------------------------------------------
    def choose_action(self, state, legal_actions, time_limit_seconds):
        budget = time_limit_seconds * self.time_fraction if self.time_fraction else None
        try:
            action = self.search(ea.board_from_public(state), budget)
            if action in legal_actions:
                return action
            problem = "search returned an action not in legal_actions"
        except Exception as error:  # a crash would forfeit the game
            if self.strict:
                raise
            problem = f"{type(error).__name__}: {error}"
        if self.strict:
            raise RuntimeError(problem)
        self.last_stats = {"fallback": problem, "depth": 0, "nodes": self.nodes, "ms": 0.0}
        return self.rng.choice(legal_actions)

    # -----------------------------------------------------------------------
    # SECTION 3: Search driver (immediate win + iterative deepening)
    # -----------------------------------------------------------------------
    def search(self, root, time_limit: float | None = None):
        start = time.perf_counter()
        self.me = self.game.current_player(root)
        self.nodes = 0
        self._deadline = start + time_limit if time_limit else None

        children = list(self.game.successors(root))
        if not children:
            raise RuntimeError("no legal actions at the root")
        self.rng.shuffle(children)              # random but reproducible tie-breaking

        for action, child in children:          # take a win immediately
            if self.game.terminal_score(child, self.me) == 1:
                self._record(start, 1, WIN_SCORE, len(children))
                return action
        if len(children) == 1:
            self._record(start, 0, 0.0, 1)
            return children[0][0]

        depths = range(1, self.max_depth + 1) if self._deadline else [self.max_depth]
        best_action, best_value, depth_done = children[0][0], 0.0, 0
        for depth in depths:
            try:
                action, value = self._search_root(children, depth, best_action if depth_done else None)
            except SearchTimeout:
                break                           # keep the deepest fully completed result
            best_action, best_value, depth_done = action, value, depth
            if abs(value) >= WIN_SCORE - 100:   # forced win/loss found; going deeper won't change it
                break

        self._record(start, depth_done, best_value, len(children))
        return best_action

    # -----------------------------------------------------------------------
    # SECTION 4: Root level (returns the action, not just a value)
    # -----------------------------------------------------------------------
    def _search_root(self, children, depth, previous_best=None):
        ordered = self._ordered(children, maximizing=True, depth=depth)
        if previous_best is not None:           # previous iteration's best goes first
            ordered.sort(key=lambda ac: ac[0] != previous_best)
        alpha, beta = -math.inf, math.inf
        best_action, best_value = ordered[0][0], -math.inf
        for action, child in ordered:
            value = self._alphabeta(child, depth - 1, alpha, beta, ply=1)
            if value > best_value:
                best_action, best_value = action, value
            alpha = max(alpha, value)
        return best_action, best_value

    # -----------------------------------------------------------------------
    # SECTION 5: Minimax with alpha-beta pruning
    # -----------------------------------------------------------------------
    def _alphabeta(self, state, depth, alpha, beta, ply):
        self.nodes += 1
        if self._deadline and time.perf_counter() > self._deadline:
            raise SearchTimeout

        result = self.game.terminal_score(state, self.me)
        if result is not None:                  # real win/loss; sooner wins score higher
            return result * (WIN_SCORE - ply)
        if depth == 0:                          # horizon: use the heuristic
            return self.game.evaluate(state, self.me)

        children = self.game.successors(state)
        maximizing = self.game.current_player(state) == self.me
        if not children:                        # side to move has no legal action -> it loses
            return (-1 if maximizing else 1) * (WIN_SCORE - ply)

        if maximizing:
            value = -math.inf
            for _, child in self._ordered(children, True, depth):
                value = max(value, self._alphabeta(child, depth - 1, alpha, beta, ply + 1))
                alpha = max(alpha, value)
                if alpha >= beta:               # opponent would never allow this line
                    break
            return value
        value = math.inf
        for _, child in self._ordered(children, False, depth):
            value = min(value, self._alphabeta(child, depth - 1, alpha, beta, ply + 1))
            beta = min(beta, value)
            if alpha >= beta:                   # we would never choose this line
                break
        return value

    # -----------------------------------------------------------------------
    # SECTION 6: Move ordering (best-first => far more pruning)
    # -----------------------------------------------------------------------
    def _ordered(self, children, maximizing, depth):
        children = list(children)
        if not self.use_ordering or depth <= 1:   # leaves get evaluated anyway
            return children
        return sorted(children, key=lambda ac: self.game.evaluate(ac[1], self.me), reverse=maximizing)

    # -----------------------------------------------------------------------
    # SECTION 7: Per-move statistics for the experiments
    # -----------------------------------------------------------------------
    def _record(self, start, depth, value, branching):
        self.last_stats = {"depth": depth, "nodes": self.nodes, "value": value,
                           "branching": branching, "ms": (time.perf_counter() - start) * 1000.0}


# ---------------------------------------------------------------------------
# SECTION 8: The function the harness loads (run_santorini.py looks for choose_action)
# ---------------------------------------------------------------------------
_BOT = SearchBot(max_depth=int(os.environ.get("SANTORINI_MAX_DEPTH", "3")),
                 seed=int(os.environ.get("SANTORINI_SEED", "0")))


def choose_action(state, legal_actions, time_limit_seconds):
    return _BOT.choose_action(state, legal_actions, time_limit_seconds)