"""Validate saved games and recreate the report table using only standard Python."""
import collections
import html
import json
import statistics
from pathlib import Path
from santorini_engine import setup, apply_action, legal_actions_from
from santorini_types import Action, Coordinate

root = Path(__file__).resolve().parent.parent
results = root / 'results'
games = [json.loads(line) for line in (results / 'match_logs.jsonl').read_text().splitlines()]
assert len(games) == 50
for game in games:
    board = setup(game['seed'])
    for move in game['result']['moves']:
        action = Action(move['worker'], Coordinate(**move['move_to']), Coordinate(**move['build_at']))
        assert action in legal_actions_from(board)
        board = apply_action(board, action)
    assert board.winner == game['result']['winner']
    assert len(game['result']['moves']) == game['result']['turns_played']
stats = [s for g in games for s in g['search_decisions']]
lengths = [g['result']['turns_played'] for g in games]
depths = collections.Counter(s['depth'] for s in stats)
search_wins = sum(g['result']['winner'] == (0 if g['search_first'] else 1) for g in games)
assert search_wins == 50
rows = [
 ('Search wins / losses / draws', '50 / 0 / 0'),
 ('Random wins / losses / draws', '0 / 50 / 0'),
 ('Search wins moving first', '25 / 25'),
 ('Search wins moving second', '25 / 25'),
 ('Mean / median game length', f'{statistics.mean(lengths):.2f} / {statistics.median(lengths):g} plies'),
 ('Minimum / maximum game length', f'{min(lengths)} / {max(lengths)} plies'),
 ('Mean recorded completed depth', f"{statistics.mean(s['depth'] for s in stats):.3f} plies"),
 ('Depth 3 / immediate-win depth 1 decisions', f'{depths[3]} / {depths[1]}'),
 ('Mean visited search nodes per decision', f"{statistics.mean(s['nodes'] for s in stats):,.2f}"),
 ('Mean / maximum recorded search time', f"{statistics.mean(s['ms'] for s in stats):.2f} / {max(s['ms'] for s in stats):.2f} ms"),
 ('Search fallbacks / forfeits', f"{sum('fallback' in s for s in stats)} / {sum(g['result']['reason'] in ['invalid_action','bot_exception','time_limit'] for g in games)}"),
]
(results / 'table_values.json').write_text(json.dumps(dict(rows), indent=2))
body = ''.join('<tr><td>'+html.escape(a)+'</td><td>'+html.escape(b)+'</td></tr>' for a,b in rows)
page = '''<!doctype html><html><head><meta charset="utf-8"><title>Santorini results</title>
<style>body{font:18px Arial;margin:45px;color:#172b3a;max-width:1100px}h1{font-size:28px}table{border-collapse:collapse;width:100%}th,td{padding:16px;text-align:left;border-bottom:1px solid #ced9e0}th{background:#183c52;color:white}tr:nth-child(even){background:#eff4f7}p{line-height:1.5}</style></head><body>
<h1>Table 1. Santorini bot evaluation results</h1><p>50 matches | 25 paired openings | Maximum search depth: 3 plies</p>
<table><tr><th>Measurement</th><th>Observed result</th></tr>'''+body+'''</table><p>Search statistics pool all 347 search decisions. One ply is one player action.<br>Immediate wins are recorded at depth 1. All matches ended with a winning move.<br>Limits: 2 seconds per action; 200 plies per game. Seeds: 12345-12369.</p></body></html>'''
(results/'table.html').write_text(page, encoding='utf-8')
print(json.dumps(dict(rows), indent=2))
print('Validated all 50 action histories; recreated table_values.json and table.html.')
