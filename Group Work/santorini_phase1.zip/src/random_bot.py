
import random
from santorini_types import Action, GameState

def choose_action(
    state: GameState,
    legal_actions: tuple[Action, ...],
    time_limit_seconds: float,
) -> Action:
    return random.choice(legal_actions)
