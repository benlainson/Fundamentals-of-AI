"""
run_experiments.py - Search bot vs. random bot through the OFFICIAL harness.

    python src/run_experiments.py --random-bot src/random_bot.py --games 50 --depths 1 2 3

Design: games come in pairs on the same seed (same opening worker placement),
with the search bot moving first in one and second in the other.
Outputs in --out: games_depth{d}.csv, summary.json, config.json
"""
import argparse
import csv
import importlib.util
import json
import math
import os
import random
import statistics
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from santorini_harness import MatchConfig, run_santorini_tournament  # noqa: E402
from search_bot import SearchBot                                     # noqa: E402


# ---------------------------------------------------------------------------
# SECTION 1: Load a bot file the same way run_santorini.py does
# ---------------------------------------------------------------------------
def load_bot(path: str):
    name = f"bot_{Path(path).stem}"
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module.choose_action


# ---------------------------------------------------------------------------
# SECTION 2: Wrapper that records the search bot's stats on every move
# ---------------------------------------------------------------------------
class InstrumentedSearchBot:
    """Callable with the harness's bot signature; logs SearchBot.last_stats."""

    def __init__(self, bot: SearchBot):
        self.bot = bot
        self.moves: list[dict] = []

    def __call__(self, state, legal_actions, time_limit_seconds):
        action = self.bot.choose_action(state, legal_actions, time_limit_seconds)
        self.moves.append(dict(self.bot.last_stats))
        return action


def mean(xs):
    return statistics.fmean(xs) if xs else 0.0


# ---------------------------------------------------------------------------
# SECTION 3: Play one game via run_santorini_tournament
# ---------------------------------------------------------------------------
def play_game(depth, random_bot, search_first, seed, args) -> dict:
    random.seed(seed)  # the random bot uses the global RNG
    fraction = None if args.fixed_depth else args.time_fraction
    search = InstrumentedSearchBot(SearchBot(max_depth=depth, seed=seed, time_fraction=fraction))
    bot_a, bot_b = (search, random_bot) if search_first else (random_bot, search)

    config = MatchConfig(move_time_limit_seconds=args.time_limit, max_turns=args.max_turns, seed=seed)
    result = run_santorini_tournament(bot_a, bot_b, config=config, num_games=1)[0]

    search_id = 0 if search_first else 1
    if result.winner is None:
        winner = "draw"
    else:
        winner = "search" if result.winner == search_id else "random"

    stats = search.moves
    return {
        "seed": seed,
        "search_first": search_first,
        "winner": winner,
        "reason": result.reason.value,          # win / no_legal_action / repetition / turn_limit / ...
        "plies": result.turns_played,
        "search_avg_nodes": round(mean([s.get("nodes", 0) for s in stats]), 1),
        "search_avg_depth": round(mean([s.get("depth", 0) for s in stats]), 2),
        "search_max_depth": max((s.get("depth", 0) for s in stats), default=0),
        "search_avg_ms": round(mean([s.get("ms", 0.0) for s in stats]), 2),
        "search_max_ms": round(max((s.get("ms", 0.0) for s in stats), default=0.0), 2),
        "fallbacks": sum("fallback" in s for s in stats),
    }


# ---------------------------------------------------------------------------
# SECTION 4: Aggregate metrics (win rate + 95% CI, end reasons, cost)
# ---------------------------------------------------------------------------
def wilson_interval(k, n, z=1.96):
    if n == 0:
        return (0.0, 0.0)
    p = k / n
    denom = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return (round(centre - half, 3), round(centre + half, 3))


def summarize(rows):
    n = len(rows)
    wins = sum(r["winner"] == "search" for r in rows)
    losses = sum(r["winner"] == "random" for r in rows)
    first = [r for r in rows if r["search_first"]]
    second = [r for r in rows if not r["search_first"]]
    return {
        "games": n,
        "search_wins": wins, "search_losses": losses, "draws": n - wins - losses,
        "search_win_rate": round(wins / n, 3) if n else 0.0,
        "win_rate_95ci": wilson_interval(wins, n),
        "wins_when_first": f"{sum(r['winner'] == 'search' for r in first)}/{len(first)}",
        "wins_when_second": f"{sum(r['winner'] == 'search' for r in second)}/{len(second)}",
        "end_reasons": dict(Counter(r["reason"] for r in rows)),
        "avg_game_length_plies": round(mean([r["plies"] for r in rows]), 2),
        "avg_length_when_search_wins": round(mean([r["plies"] for r in rows if r["winner"] == "search"]), 2),
        "avg_nodes_per_move": round(mean([r["search_avg_nodes"] for r in rows]), 1),
        "avg_depth_completed": round(mean([r["search_avg_depth"] for r in rows]), 2),
        "avg_ms_per_move": round(mean([r["search_avg_ms"] for r in rows]), 2),
        "slowest_move_ms": max((r["search_max_ms"] for r in rows), default=0.0),
        "fallback_moves": sum(r["fallbacks"] for r in rows),
    }


# ---------------------------------------------------------------------------
# SECTION 5: Command line
# ---------------------------------------------------------------------------
def main():
    p = argparse.ArgumentParser(description="Search bot vs random bot via the official harness")
    p.add_argument("--random-bot", required=True)
    p.add_argument("--games", type=int, default=50)
    p.add_argument("--depths", type=int, nargs="+", default=[2])
    p.add_argument("--time-limit", type=float, default=2.0, help="harness seconds per move")
    p.add_argument("--time-fraction", type=float, default=0.75, help="share of the limit the search uses")
    p.add_argument("--fixed-depth", action="store_true",
                   help="always search exactly max depth (fully reproducible; raise --time-limit)")
    p.add_argument("--max-turns", type=int, default=200)
    p.add_argument("--seed", type=int, default=12345)
    p.add_argument("--out", default="results")
    args = p.parse_args()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    random_bot = load_bot(args.random_bot)
    summaries = {}

    for depth in args.depths:
        rows = []
        for i in range(args.games):
            seed = args.seed + i // 2               # each opening is played twice
            row = play_game(depth, random_bot, search_first=(i % 2 == 0), seed=seed, args=args)
            row["game"], row["depth"] = i, depth
            rows.append(row)
            print(f"depth={depth} game={i:02d} seed={seed} winner={row['winner']:<6} "
                  f"reason={row['reason']:<15} plies={row['plies']}")

        with open(out / f"games_depth{depth}.csv", "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
        summaries[f"depth_{depth}"] = summarize(rows)
        print(json.dumps(summaries[f"depth_{depth}"], indent=2))

    (out / "summary.json").write_text(json.dumps(summaries, indent=2))
    (out / "config.json").write_text(json.dumps({
        **vars(args),
        "game_seeds": [args.seed + i // 2 for i in range(args.games)],
        "pairing": "game 2k and 2k+1 share a seed; search bot moves first in even games",
    }, indent=2))


if __name__ == "__main__":
    main()