"""
engine_adapter.py - Connects the official engine (santorini_engine / santorini_types)
to our heuristic and search. The engine files are only imported, never modified.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from santorini_engine import BoardState, successors as engine_successors  # noqa: E402
from santorini_types import Coordinate, GameState                          # noqa: E402
from heuristic import BoardView, evaluate                                  # noqa: E402

# Inside the search, the bot is always engine player 0 and the opponent is player 1.
ME, OPPONENT = 0, 1


# ---------------------------------------------------------------------------
# SECTION 1: Rebuild an engine BoardState from the bot's public GameState
# ---------------------------------------------------------------------------
def board_from_public(state: GameState) -> BoardState:
    """The harness gives the bot a GameState from its own perspective.
    The engine's successors() needs a BoardState, so we rebuild one in which
    we are player 0 and it is our turn. Heights already use 0-4 (4 = dome)."""
    return BoardState(
        heights=state.heights,
        workers=(tuple(state.current_workers), tuple(state.opponent_workers)),
        current_player=ME,
        turn_number=state.turn_number,
        winner=None,
    )


# ---------------------------------------------------------------------------
# SECTION 2: Convert a BoardState into the heuristic's BoardView
# ---------------------------------------------------------------------------
def cells(workers: tuple[Coordinate, ...]) -> tuple[tuple[int, int], ...]:
    return tuple((w.row, w.column) for w in workers)


def to_view(board: BoardState, player: int) -> BoardView:
    return BoardView(board.heights, cells(board.workers[player]), cells(board.workers[1 - player]))


# ---------------------------------------------------------------------------
# SECTION 3: Game interface used by SearchBot
# ---------------------------------------------------------------------------
class SantoriniGame:
    """The four operations the search needs. Tests substitute small fake games."""

    def __init__(self, weights: dict | None = None):
        self.weights = weights

    def current_player(self, board: BoardState) -> int:
        return board.current_player

    def successors(self, board: BoardState):
        """(Action, BoardState) pairs straight from the official engine."""
        return engine_successors(board)

    def terminal_score(self, board: BoardState, player: int):
        """+1 / -1 if someone has won, else None. (A player with no legal
        action shows up as an empty successor list and is handled in the search.)"""
        if board.winner is None:
            return None
        return 1 if board.winner == player else -1

    def evaluate(self, board: BoardState, player: int) -> float:
        return evaluate(to_view(board, player), board.current_player == player, self.weights)