import sys, random, json, csv, time, hashlib, platform
from pathlib import Path
from dataclasses import asdict
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT/'src'))
from search_bot import SearchBot
from random_bot import choose_action as random_action
from santorini_harness import MatchConfig, run_santorini_tournament
from run_experiments import summarize
OUT = ROOT/'results'/'rerun'
OUT.mkdir(exist_ok=True)
rows=[]
config={'games':50,'max_depth':3,'time_fraction':0.75,'time_limit_seconds':2.0,'max_turns':200,'seeds':list(range(12345,12370)), 'python':platform.python_version(), 'platform':platform.platform(), 'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'src').glob('*.py')}}
(OUT/'config.json').write_text(json.dumps(config,indent=2))
with (OUT/'match_logs.jsonl').open('w') as logs:
 for i in range(50):
  seed=12345+i//2; first=i%2==0; random.seed(seed)
  bot=SearchBot(max_depth=3,seed=seed,time_fraction=.75)
  decisions=[]
  def search(state, actions, limit):
   action=bot.choose_action(state,actions,limit)
   decisions.append({'turn':state.turn_number,**bot.last_stats})
   return action
  a,b=(search,random_action) if first else (random_action,search)
  result=run_santorini_tournament(a,b,MatchConfig(2.0,200,seed),1)[0]
  sid=0 if first else 1
  winner='draw' if result.winner is None else ('search' if result.winner==sid else 'random')
  avg=lambda k:sum(s[k] for s in decisions)/len(decisions) if decisions else 0
  row=dict(game=i+1,seed=seed,search_first=first,winner=winner,reason=result.reason.value,plies=result.turns_played,search_avg_nodes=avg('nodes'),search_avg_depth=avg('depth'),search_max_depth=max((s['depth'] for s in decisions),default=0),search_avg_ms=avg('ms'),search_max_ms=max((s['ms'] for s in decisions),default=0),fallbacks=sum('fallback' in s for s in decisions))
  rows.append(row)
  logs.write(json.dumps({'game':i+1,'seed':seed,'search_first':first,'result':asdict(result),'search_decisions':decisions})+'\n'); logs.flush()
  with (OUT/'games.csv').open('w',newline='') as f:
   w=csv.DictWriter(f,fieldnames=list(row));w.writeheader();w.writerows(rows)
  (OUT/'summary.json').write_text(json.dumps(summarize(rows),indent=2))
  print(f"Game {i+1}/50: {winner}, {result.reason.value}, {result.turns_played} plies",flush=True)
