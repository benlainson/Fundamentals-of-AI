"""
heuristic.py - Board evaluation and movement rules for the search bot.

This module is deliberately independent of the official engine: it re-implements
Santorini movement on a light-weight ``BoardView`` so the search can score and
expand positions without constructing engine objects. ``engine_adapter`` is the
only place the two representations meet, and ``test_engine_integration`` pins our
movement rules to the official ``legal_actions_from`` so they can never drift.

Coordinates are plain ``(row, column)`` tuples. Heights use the engine's 0-4
encoding (0 = ground, 1-3 = building levels, 4 = dome). A worker wins by moving
onto a level-3 square; that outcome is handled by the search's terminal check,
so ``evaluate`` never sees a worker standing on level 3.
"""
from typing import NamedTuple, Optional

BOARD_SIZE = 5
DOME = 4

# A score no real heuristic value can reach, so the search can tell a forced
# win/loss (WIN_SCORE - ply) apart from an ordinary evaluated position.
WIN_SCORE = 1_000_000

# The eight king-move neighbour offsets, matching the engine's adjacency.
NEIGHBOR_OFFSETS = (
    (-1, -1), (-1, 0), (-1, 1),
    (0, -1),           (0, 1),
    (1, -1),  (1, 0),  (1, 1),
)


class BoardView(NamedTuple):
    """A minimal, immutable board from one player's perspective.

    ``my_workers`` and ``opp_workers`` are tuples of ``(row, column)`` cells;
    ``heights[row][column]`` is the 0-4 height of that square.
    """

    heights: tuple
    my_workers: tuple
    opp_workers: tuple


def _in_bounds(row: int, column: int) -> bool:
    return 0 <= row < BOARD_SIZE and 0 <= column < BOARD_SIZE


def legal_moves(view: BoardView, worker, occupied):
    """Legal move destinations for ``worker`` on ``view`` (spec movement rules).

    ``worker`` is a ``(row, column)`` cell and ``occupied`` is the set of all
    worker cells (both players). A destination is legal when it is an in-bounds
    neighbour that is unoccupied, not domed, and at most one level above the
    worker's current square. This mirrors the engine's
    ``_legal_move_destinations`` exactly, which the integration test enforces.
    """
    row, column = worker
    source_height = view.heights[row][column]
    destinations = []
    for row_offset, column_offset in NEIGHBOR_OFFSETS:
        neighbor = (row + row_offset, column + column_offset)
        if not _in_bounds(*neighbor):
            continue
        if neighbor in occupied:
            continue
        destination_height = view.heights[neighbor[0]][neighbor[1]]
        if destination_height == DOME:
            continue
        if destination_height > source_height + 1:
            continue
        destinations.append(neighbor)
    return tuple(destinations)


def win_threats(view: BoardView, worker, occupied):
    """Legal moves for ``worker`` that win immediately (step onto a level-3 square)."""
    return tuple(
        move for move in legal_moves(view, worker, occupied)
        if view.heights[move[0]][move[1]] == 3
    )


# ---------------------------------------------------------------------------
# Evaluation
# ---------------------------------------------------------------------------
# Standing high is good, and standing on level 2 is worth far more than level 1
# because it is one step from winning.
HEIGHT_VALUE = (0, 15, 60, 300, 300)

# Central squares reach more of the board, so they are worth holding.
CENTER_VALUE = tuple(
    tuple(2 - max(abs(row - 2), abs(column - 2)) for column in range(BOARD_SIZE))
    for row in range(BOARD_SIZE)
)

DEFAULT_WEIGHTS = {
    "height": 20,     # occupied-square height
    "center": 5,      # board centrality
    "mobility": 3,    # number of legal moves
    "climb": 6,       # moves that go one level up (progress toward a win)
    "win_ready": 80,  # a move that would win outright next turn
}


def _side_score(view: BoardView, workers, occupied, weights) -> float:
    height = 0
    center = 0
    mobility = 0
    climb = 0
    win_ready = 0
    for worker in workers:
        row, column = worker
        worker_height = view.heights[row][column]
        height += HEIGHT_VALUE[worker_height]
        center += CENTER_VALUE[row][column]
        for move in legal_moves(view, worker, occupied):
            mobility += 1
            move_height = view.heights[move[0]][move[1]]
            if move_height == worker_height + 1:
                climb += 1
            if move_height == 3:
                win_ready += 1
    return (
        weights["height"] * height
        + weights["center"] * center
        + weights["mobility"] * mobility
        + weights["climb"] * climb
        + weights["win_ready"] * win_ready
    )


def evaluate(view: BoardView, my_turn: bool, weights: Optional[dict] = None) -> float:
    """Score ``view`` from the perspective of ``my_workers`` (higher is better).

    The score is my advantage minus the opponent's over height, centrality,
    mobility, climbing chances, and immediate winning threats. ``my_turn`` says
    whether the perspective player is about to move, which makes a standing
    winning threat worth more (there is a tempo to convert it). The result is
    always well within +/-WIN_SCORE so the search never mistakes it for a
    forced win.
    """
    weights = DEFAULT_WEIGHTS if weights is None else {**DEFAULT_WEIGHTS, **weights}
    occupied = set(view.my_workers) | set(view.opp_workers)

    my_score = _side_score(view, view.my_workers, occupied, weights)
    opp_score = _side_score(view, view.opp_workers, occupied, weights)

    # Whoever is to move gets a small edge on the shared tempo.
    tempo = weights["mobility"] if my_turn else -weights["mobility"]
    return float(my_score - opp_score + tempo)
