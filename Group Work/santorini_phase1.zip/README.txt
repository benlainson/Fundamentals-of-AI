SANTORINI PHASE 1
Ben Ferber and Ben Lainson

REQUIREMENTS
Python 3.10 or newer is required by the source syntax.
Evaluation and all 74 tests were run with Python 3.13.16 on Windows.
The bots and match harness use only the Python standard library.
requirements.txt lists development tools: pytest, pytest-cov, and ruff.
No API keys or network access are needed to play matches.

INSTALLATION (Windows PowerShell)
Extract the zip, open PowerShell in the extracted folder containing this README,
and run these commands. Python 3.13 must already be installed.

py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m pip install -e .

RUN A LOCAL MATCH WITH THE SEARCH BOT
.\.venv\Scripts\python.exe src/run_santorini.py --bot1 src/search_bot.py --bot2 src/random_bot.py --seed 12345 --time-limit 2.0 --num-games 1

RUN THE RANDOM BOT FIRST
.\.venv\Scripts\python.exe src/run_santorini.py --bot1 src/random_bot.py --bot2 src/search_bot.py --seed 12345 --time-limit 2.0 --num-games 1

Bots expose choose_action(state, legal_actions, time_limit_seconds); they are
loaded by the runner and do not have a separate interactive command.
The CLI seed controls opening placement. Use the paired evaluation below to
also seed both bots' random choices and reproduce the experimental method.

RUN ALL TESTS
.\.venv\Scripts\python.exe -m pytest -q

REPEAT THE RECORDED 50-GAME EXPERIMENT
.\.venv\Scripts\python.exe src/evaluate_submission.py

This uses 25 seeds (12345 through 12369), two games per seed with bot order
reversed, maximum search depth 3, a 2-second action limit, a 75% internal
search budget, and a 200-ply cap. It writes to results/rerun/ and preserves
the submitted original results. Timing and time-limited decisions can vary
with machine load and hardware. A ply means one player's action.

ALTERNATIVE PROVIDED EXPERIMENT RUNNER
.\.venv\Scripts\python.exe src/run_experiments.py --random-bot src/random_bot.py --games 50 --depths 3 --time-limit 2.0 --time-fraction 0.75 --max-turns 200 --seed 12345 --out results/alternative_rerun

REPRODUCE TABLE VALUES FROM SAVED LOGS (no matches required)
.\.venv\Scripts\python.exe src/reproduce_table.py

This checks recorded actions against the engine, recomputes the table values,
and writes results/table_values.json and results/table.html. Open table.html
in a browser to view or screenshot the labeled table without extra packages.
The submitted PNG is the same data in the report's original presentation.

CONTENTS AND METRIC DEFINITIONS
santorini_phase1.docx: report with a labeled results table and two games.
GenAI.docx: both authors' supplied reflections and conversation share links.
src/: bots, heuristic, engine adapter, provided engine/harness, runners.
tests/: all 74 tests used in verification.
results/games.csv: one row per game, using game numbers 1 through 50.
results/match_logs.jsonl: all actions and per-decision search measurements.
results/config.json: settings, environment, seeds, original source hashes.
results/summary.json: original summary (equal weight for each game's mean).
results/Santorini_Results_Table.png: report table (equal weight per decision).
results/table_values.json: recomputed values pooled over 347 decisions.

There are 297 recorded depth-three decisions and 50 immediate-win decisions
recorded at depth one. The latter explain the average depth below three.
Search time is the bot's internal recorded time, not full harness overhead.
Source hashes in config.json describe the original evaluated files; the
submission additionally includes portable reproduction utilities.
The in-process harness detects time overruns after a bot returns; it does
not forcibly terminate a hanging bot. Trusted engine files are unchanged.

